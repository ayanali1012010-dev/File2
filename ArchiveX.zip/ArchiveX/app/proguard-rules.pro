# Minification is disabled for this project; add keep rules here if you enable it.
-dontwarn org.tukaani.xz.**
-dontwarn org.apache.commons.compress.**
-dontwarn com.github.junrar.**
