package dev.archivex.app.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.archivex.app.archive.ArchiveEngine
import dev.archivex.app.archive.ArchiveFormat
import dev.archivex.app.archive.EntryInfo
import dev.archivex.app.archive.Level
import dev.archivex.app.archive.PasswordIssue
import dev.archivex.app.archive.WrongPassword
import dev.archivex.app.data.FileProps
import dev.archivex.app.data.FileRepository
import dev.archivex.app.data.StorageManager
import dev.archivex.app.data.StorageRoot
import dev.archivex.app.model.CancelToken
import dev.archivex.app.model.FileItem
import dev.archivex.app.model.FileType
import dev.archivex.app.model.OperationCancelled
import dev.archivex.app.model.OperationProgress
import dev.archivex.app.model.SortField
import dev.archivex.app.model.SortOption
import dev.archivex.app.model.Sorter
import dev.archivex.app.model.defaultArchiveName
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class ArchiveSession(
    val file: File,
    val password: String?,
    val entries: List<EntryInfo>,
    /** Normalized path of the folder currently shown inside the archive ("" = archive root). */
    val innerPath: String,
)

data class Clipboard(val files: List<File>, val move: Boolean)

sealed interface UiDialog {
    object NewFolder : UiDialog
    object SortAndView : UiDialog
    data class Rename(val item: FileItem) : UiDialog
    data class Delete(val items: List<FileItem>) : UiDialog
    data class Props(val props: FileProps) : UiDialog
    data class Compress(val items: List<FileItem>) : UiDialog
    data class FolderPicker(val start: File, val onPick: (File) -> Unit) : UiDialog
    data class Password(val archiveName: String, val wrong: Boolean, val onSubmit: (String) -> Unit) : UiDialog
}

sealed interface UiEvent {
    data class OpenFile(val file: File) : UiEvent
}

data class UiState(
    val hasPermission: Boolean = false,
    val roots: List<StorageRoot> = emptyList(),
    val currentDir: File = File("/"),
    val archive: ArchiveSession? = null,
    val items: List<FileItem> = emptyList(),
    val loading: Boolean = false,
    val selecting: Boolean = false,
    val selection: Set<String> = emptySet(),
    val sort: SortOption = SortOption(),
    val showHidden: Boolean = false,
    val darkTheme: Boolean = true,
    val accent: Int = 0,
    val clipboard: Clipboard? = null,
    val progress: OperationProgress? = null,
    val dialog: UiDialog? = null,
    val sheet: List<FileItem>? = null,
    val message: String? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx: Application get() = getApplication()
    private val storage = StorageManager(app)
    private val repo = FileRepository()
    private val engine = ArchiveEngine()
    private val prefs = app.getSharedPreferences("archivex", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(initialState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events = _events.receiveAsFlow()

    private var listJob: Job? = null
    private var opJob: Job? = null
    private var token: CancelToken? = null

    private fun initialState(): UiState {
        val roots = storage.roots()
        val last = prefs.getString("last_dir", null)?.let { File(it) }
        val start = if (last != null && last.isDirectory) last else roots.first().path
        val field = runCatching { SortField.valueOf(prefs.getString("sort_field", "NAME") ?: "NAME") }.getOrDefault(SortField.NAME)
        return UiState(
            hasPermission = storage.hasAllFilesAccess(),
            roots = roots,
            currentDir = start,
            sort = SortOption(field, prefs.getBoolean("sort_asc", true)),
            showHidden = prefs.getBoolean("hidden", false),
            darkTheme = prefs.getBoolean("dark", true),
            accent = prefs.getInt("accent", 0),
        )
    }

    init {
        if (_state.value.hasPermission) load(_state.value.currentDir)
    }

    fun accessIntent(): Intent = storage.allFilesAccessIntent()

    fun refreshPermission() {
        val granted = storage.hasAllFilesAccess()
        if (granted != _state.value.hasPermission) {
            _state.update { it.copy(hasPermission = granted, roots = storage.roots()) }
            if (granted) load(_state.value.currentDir)
        }
    }

    // ------------------------------------------------------------ navigation

    fun navigate(dir: File) {
        _state.update { it.copy(archive = null) }
        load(dir)
    }

    private fun load(dir: File) {
        listJob?.cancel()
        listJob = viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val s = _state.value
            try {
                val items = repo.list(dir, s.sort, s.showHidden)
                prefs.edit().putString("last_dir", dir.absolutePath).apply()
                _state.update {
                    it.copy(currentDir = dir, items = items, selection = emptySet(), selecting = false, loading = false, archive = null)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false) }
                message(e.message ?: "Cannot open folder")
            }
        }
    }

    fun reload() {
        val session = _state.value.archive
        if (session != null) showArchiveFolder(session.innerPath) else load(_state.value.currentDir)
    }

    /** Returns true when the back press was consumed. */
    fun onBack(): Boolean {
        val s = _state.value
        if (s.selecting) { clearSelection(); return true }
        val session = s.archive
        if (session != null) {
            if (session.innerPath.isEmpty()) closeArchive() else showArchiveFolder(session.innerPath.substringBeforeLast('/', ""))
            return true
        }
        val isRoot = s.roots.any { it.path.absolutePath == s.currentDir.absolutePath }
        val parent = s.currentDir.parentFile
        if (!isRoot && parent != null && parent.canRead()) { navigate(parent); return true }
        return false
    }

    fun onItemClick(item: FileItem) {
        val s = _state.value
        if (s.selecting) { toggleSelection(item.key); return }
        if (s.archive != null) {
            if (item.isDir) showArchiveFolder(item.key) else previewEntry(item)
            return
        }
        val f = item.file ?: return
        when {
            item.isDir -> navigate(f)
            item.type == FileType.ARCHIVE && ArchiveEngine.kindOf(f) != null -> openArchive(f, null)
            else -> viewModelScope.launch { _events.send(UiEvent.OpenFile(f)) }
        }
    }

    fun onItemLongClick(item: FileItem) {
        val s = _state.value
        val targets = if (item.key in s.selection) s.items.filter { it.key in s.selection } else listOf(item)
        _state.update { it.copy(sheet = targets) }
    }

    fun openSheetForSelection() {
        val s = _state.value
        val targets = s.items.filter { it.key in s.selection }
        if (targets.isNotEmpty()) _state.update { it.copy(sheet = targets) }
    }

    fun dismissSheet() = _state.update { it.copy(sheet = null) }
    fun dismissDialog() = _state.update { it.copy(dialog = null) }
    fun showDialog(d: UiDialog) = _state.update { it.copy(dialog = d, sheet = null) }
    fun messageShown() = _state.update { it.copy(message = null) }
    private fun message(text: String) = _state.update { it.copy(message = text) }

    // ------------------------------------------------------------- selection

    fun startSelecting() = _state.update { it.copy(selecting = true) }
    fun clearSelection() = _state.update { it.copy(selecting = false, selection = emptySet()) }
    fun selectAll() = _state.update { it.copy(selecting = true, selection = it.items.map { i -> i.key }.toSet()) }
    fun toggleSelection(key: String) = _state.update {
        val ns = if (key in it.selection) it.selection - key else it.selection + key
        it.copy(selection = ns, selecting = true)
    }

    fun selectedItems(): List<FileItem> {
        val s = _state.value
        return s.items.filter { it.key in s.selection }
    }

    // ---------------------------------------------------------- sort & prefs

    fun setSort(field: SortField, ascending: Boolean) {
        prefs.edit().putString("sort_field", field.name).putBoolean("sort_asc", ascending).apply()
        _state.update { it.copy(sort = SortOption(field, ascending)) }
        reload()
    }

    fun setShowHidden(show: Boolean) {
        prefs.edit().putBoolean("hidden", show).apply()
        _state.update { it.copy(showHidden = show) }
        reload()
    }

    fun setAccent(i: Int) {
        prefs.edit().putInt("accent", i).apply()
        _state.update { it.copy(accent = i) }
    }

    fun setDark(dark: Boolean) {
        prefs.edit().putBoolean("dark", dark).apply()
        _state.update { it.copy(darkTheme = dark) }
    }

    // --------------------------------------------------------- file actions

    fun createFolder(name: String) {
        val dir = _state.value.currentDir
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { repo.createFolder(dir, name.trim()) }
                dismissDialog()
                reload()
            } catch (e: Exception) { message(e.message ?: "Could not create folder") }
        }
    }

    fun rename(item: FileItem, newName: String) {
        val f = item.file ?: return
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { repo.rename(f, newName.trim()) }
                dismissDialog()
                reload()
            } catch (e: Exception) { message(e.message ?: "Could not rename") }
        }
    }

    fun delete(items: List<FileItem>) {
        val files = items.mapNotNull { it.file }
        dismissDialog()
        runOp("Deleting") { t, _ ->
            val failed = repo.delete(files, t)
            if (failed == 0) "Deleted ${files.size} item(s)" else "Could not delete $failed item(s)"
        }
    }

    fun showProperties(item: FileItem) {
        val f = item.file ?: return
        viewModelScope.launch {
            val props = withContext(Dispatchers.IO) { repo.properties(f) }
            _state.update { it.copy(dialog = UiDialog.Props(props), sheet = null) }
        }
    }

    fun copyToClipboard(items: List<FileItem>, move: Boolean) {
        val files = items.mapNotNull { it.file }
        if (files.isEmpty()) return
        _state.update { it.copy(clipboard = Clipboard(files, move), sheet = null, selecting = false, selection = emptySet()) }
        message("${files.size} item(s) ${if (move) "cut" else "copied"}. Open a folder and tap Paste.")
    }

    fun clearClipboard() = _state.update { it.copy(clipboard = null) }

    fun paste() {
        val cb = _state.value.clipboard ?: return
        val dest = _state.value.currentDir
        runOp(if (cb.move) "Moving" else "Copying") { t, sink ->
            val n = repo.paste(cb.files, dest, cb.move, t, sink)
            if (cb.move) _state.update { it.copy(clipboard = null) }
            "${if (cb.move) "Moved" else "Copied"} $n item(s)"
        }
    }

    // ------------------------------------------------------------- archives

    fun compress(items: List<FileItem>, name: String, format: ArchiveFormat, level: Level, password: String?) {
        val files = items.mapNotNull { it.file }
        if (files.isEmpty()) return
        val dir = _state.value.currentDir
        val clean = name.trim().ifEmpty { "Archive" }.replace('/', '_')
        val pw = password?.takeIf { it.isNotEmpty() && format.supportsPassword }
        _state.update { it.copy(dialog = null, sheet = null, selecting = false, selection = emptySet()) }
        runOp("Compressing") { t, sink ->
            val out = repo.uniqueFile(dir, clean + format.ext)
            engine.create(files, out, format, level, pw, t, sink)
            "Created ${out.name}"
        }
    }

    fun quickCompress(items: List<FileItem>, format: ArchiveFormat) =
        compress(items, defaultArchiveName(items), format, Level.NORMAL, null)

    fun openArchive(file: File, password: String?) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            try {
                val entries = withContext(Dispatchers.IO) { engine.list(file, password) }
                val session = ArchiveSession(file, password, entries, "")
                _state.update {
                    it.copy(
                        archive = session, selecting = false, selection = emptySet(), loading = false,
                        items = archiveView(session, it.sort),
                    )
                }
            } catch (e: PasswordIssue) {
                _state.update {
                    it.copy(loading = false, dialog = UiDialog.Password(file.name, e is WrongPassword) { pw -> openArchive(file, pw) })
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false) }
                message("Cannot open archive: ${e.message ?: "unknown error"}")
            }
        }
    }

    private fun closeArchive() {
        _state.update { it.copy(archive = null) }
        load(_state.value.currentDir)
    }

    fun closeArchiveNow() = closeArchive()

    fun showArchiveFolder(inner: String) {
        val session = _state.value.archive ?: return
        val updated = session.copy(innerPath = inner)
        _state.update { it.copy(archive = updated, items = archiveView(updated, it.sort), selection = emptySet(), selecting = false) }
    }

    private fun archiveView(session: ArchiveSession, sort: SortOption): List<FileItem> {
        val inner = session.innerPath
        val prefix = if (inner.isEmpty()) "" else "$inner/"
        val map = LinkedHashMap<String, FileItem>()
        for (e in session.entries) {
            val p = e.path
            if (p == inner || !p.startsWith(prefix)) continue
            val rest = p.removePrefix(prefix)
            if (rest.isEmpty()) continue
            val first = rest.substringBefore('/')
            val key = prefix + first
            if (rest.contains('/') || e.isDir) {
                map.getOrPut(key) { FileItem(key, first, true, 0L, e.modified, FileType.FOLDER, null) }
            } else {
                map[key] = FileItem(key, first, false, e.size.coerceAtLeast(0L), e.modified, dev.archivex.app.model.FileTypes.of(first, false), null)
            }
        }
        return Sorter.sort(map.values.toList(), sort)
    }

    fun previewEntry(item: FileItem) {
        val s = _state.value.archive ?: return
        val dir = File(ctx.cacheDir, "preview")
        extractJob(s.file, dir, setOf(item.key), s.password, previewKey = item.key, doneMessage = null)
    }

    fun extractHere(archive: File) =
        extractJob(archive, archive.parentFile ?: _state.value.currentDir, null, null, null, "Extracted ${archive.name}")

    fun extractToNamedFolder(archive: File) {
        val parent = archive.parentFile ?: _state.value.currentDir
        val dest = repo.uniqueFile(parent, ArchiveEngine.baseName(archive.name).ifEmpty { "extracted" })
        extractJob(archive, dest, null, null, null, "Extracted to ${dest.name}")
    }

    fun extractToPicker(archive: File) {
        val start = archive.parentFile ?: _state.value.currentDir
        showDialog(UiDialog.FolderPicker(start) { dest ->
            extractJob(archive, dest, null, null, null, "Extracted to ${dest.name}")
        })
    }

    /** Inside an archive session: extract the chosen entries (or everything when [items] is null). */
    fun extractFromSession(items: List<FileItem>?, toArchiveFolder: Boolean) {
        val session = _state.value.archive ?: return
        val keys = items?.map { it.key }?.toSet()
        if (toArchiveFolder) {
            val dest = session.file.parentFile ?: _state.value.currentDir
            extractJob(session.file, dest, keys, session.password, null, "Extracted to ${dest.name}")
        } else {
            showDialog(UiDialog.FolderPicker(session.file.parentFile ?: _state.value.currentDir) { dest ->
                extractJob(session.file, dest, keys, session.password, null, "Extracted to ${dest.name}")
            })
        }
    }

    private fun extractJob(archive: File, dest: File, selected: Set<String>?, password: String?, previewKey: String?, doneMessage: String?) {
        runOp(
            title = "Extracting ${archive.name}",
            onPasswordIssue = { wrong ->
                _state.update {
                    it.copy(dialog = UiDialog.Password(archive.name, wrong) { pw ->
                        rememberPassword(archive, pw)
                        extractJob(archive, dest, selected, pw, previewKey, doneMessage)
                    })
                }
            },
        ) { t, sink ->
            if (previewKey != null) { dest.deleteRecursively(); dest.mkdirs() }
            engine.extract(archive, dest, password, selected, t, sink)
            if (previewKey != null) {
                _events.send(UiEvent.OpenFile(File(dest, previewKey)))
                null
            } else doneMessage
        }
    }

    private fun rememberPassword(archive: File, pw: String) {
        _state.update { s ->
            val session = s.archive
            if (session != null && session.file == archive) s.copy(archive = session.copy(password = pw)) else s
        }
    }

    // ------------------------------------------------------------ operations

    fun cancelOperation() { token?.cancel() }

    private fun runOp(
        title: String,
        onPasswordIssue: ((wrong: Boolean) -> Unit)? = null,
        block: suspend (CancelToken, (OperationProgress) -> Unit) -> String?,
    ) {
        if (opJob?.isActive == true) { message("Another operation is still running"); return }
        val t = CancelToken()
        token = t
        _state.update { it.copy(progress = OperationProgress(title, -1, "", 0L)) }
        startForegroundNotification(title)
        opJob = viewModelScope.launch {
            try {
                val msg = withContext(Dispatchers.IO) {
                    block(t) { p -> _state.update { s -> if (s.progress != null) s.copy(progress = p) else s } }
                }
                if (msg != null) message(msg)
            } catch (e: OperationCancelled) {
                message("Cancelled")
            } catch (e: PasswordIssue) {
                if (onPasswordIssue != null) onPasswordIssue(e is WrongPassword) else message(e.message ?: "Password problem")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message(e.message ?: "Operation failed")
            } finally {
                _state.update { it.copy(progress = null) }
                stopForegroundNotification()
                reload()
            }
        }
    }

    private fun startForegroundNotification(title: String) {
        try {
            val i = Intent(ctx, OperationService::class.java).putExtra(OperationService.EXTRA_TITLE, title)
            ContextCompat.startForegroundService(ctx, i)
        } catch (_: Exception) { /* background start restrictions: the operation still runs while the app is open */ }
    }

    private fun stopForegroundNotification() {
        try { ctx.stopService(Intent(ctx, OperationService::class.java)) } catch (_: Exception) { }
    }
}
