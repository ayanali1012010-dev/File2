package dev.archivex.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.archivex.app.archive.ArchiveFormat
import dev.archivex.app.archive.Level
import dev.archivex.app.data.FileProps
import dev.archivex.app.data.StorageRoot
import dev.archivex.app.model.FileItem
import dev.archivex.app.model.OperationProgress
import dev.archivex.app.model.SortField
import dev.archivex.app.model.defaultArchiveName
import dev.archivex.app.model.formatSize
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DialogHost(s: UiState, vm: MainViewModel) {
    when (val d = s.dialog) {
        null -> Unit
        is UiDialog.NewFolder -> TextInputDialog(
            title = "New folder", label = "Folder name", initial = "", confirm = "Create",
            onDismiss = vm::dismissDialog, onConfirm = vm::createFolder,
        )
        is UiDialog.Rename -> TextInputDialog(
            title = "Rename", label = "New name", initial = d.item.name, confirm = "Rename",
            onDismiss = vm::dismissDialog, onConfirm = { vm.rename(d.item, it) },
        )
        is UiDialog.Delete -> AlertDialog(
            onDismissRequest = vm::dismissDialog,
            title = { Text("Delete ${d.items.size} item(s)?") },
            text = { Text("Folders are deleted with everything inside them. This cannot be undone.") },
            confirmButton = { TextButton(onClick = { vm.delete(d.items) }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = vm::dismissDialog) { Text("Cancel") } },
        )
        is UiDialog.Props -> PropsDialog(d.props, vm::dismissDialog)
        is UiDialog.Compress -> CompressDialog(
            items = d.items,
            onDismiss = vm::dismissDialog,
            onConfirm = { name, format, level, pw -> vm.compress(d.items, name, format, level, pw) },
        )
        is UiDialog.SortAndView -> SortDialog(s, vm)
        is UiDialog.FolderPicker -> FolderPickerDialog(
            start = d.start, roots = s.roots, onDismiss = vm::dismissDialog,
            onPick = { dir -> vm.dismissDialog(); d.onPick(dir) },
        )
        is UiDialog.Password -> PasswordDialog(d.archiveName, d.wrong, vm::dismissDialog) { pw ->
            vm.dismissDialog()
            d.onSubmit(pw)
        }
    }
}

@Composable
fun TextInputDialog(
    title: String,
    label: String,
    initial: String,
    confirm: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun PropsDialog(p: FileProps, onDismiss: () -> Unit) {
    val fmt = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Details") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PropLine("Name", p.name)
                PropLine("Location", p.path)
                PropLine("Type", p.kind)
                PropLine("Size", "${formatSize(p.size)} (${p.size} bytes)")
                if (p.kind == "Folder") PropLine("Contains", "${p.files} files, ${p.folders} folders")
                PropLine("Modified", if (p.modified > 0) fmt.format(Date(p.modified)) else "Unknown")
                PropLine("Access", buildString {
                    append(if (p.readable) "Read" else "No read")
                    append(", ")
                    append(if (p.writable) "Write" else "No write")
                    if (p.hidden) append(", Hidden")
                })
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun PropLine(k: String, v: String) {
    Column {
        Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun CompressDialog(
    items: List<FileItem>,
    onDismiss: () -> Unit,
    onConfirm: (String, ArchiveFormat, Level, String?) -> Unit,
) {
    var name by remember { mutableStateOf(defaultArchiveName(items)) }
    var format by remember { mutableStateOf(ArchiveFormat.ZIP) }
    var level by remember { mutableStateOf(Level.NORMAL) }
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    val pwMismatch = format.supportsPassword && pw != pw2

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create archive") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Name") },
                    singleLine = true, suffix = { Text(format.ext) },
                )
                Text("Format", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ArchiveFormat.values().forEach { f ->
                        FilterChip(selected = format == f, onClick = { format = f }, label = { Text(f.label) })
                    }
                }
                Text("Compression", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Level.values().forEach { l ->
                        FilterChip(selected = level == l, onClick = { level = l }, label = { Text(l.label) })
                    }
                }
                OutlinedTextField(
                    value = pw, onValueChange = { pw = it }, label = { Text("Password (optional)") },
                    singleLine = true, enabled = format.supportsPassword,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    supportingText = { if (!format.supportsPassword) Text("Passwords are available for ZIP (AES-256)") },
                )
                if (format.supportsPassword && pw.isNotEmpty()) {
                    OutlinedTextField(
                        value = pw2, onValueChange = { pw2 = it }, label = { Text("Repeat password") },
                        singleLine = true, isError = pwMismatch,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(name, format, level, pw.takeIf { it.isNotEmpty() }) },
                enabled = name.isNotBlank() && !pwMismatch,
            ) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun PasswordDialog(archiveName: String, wrong: Boolean, onDismiss: () -> Unit, onSubmit: (String) -> Unit) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Password required") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(archiveName, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(
                    value = pw, onValueChange = { pw = it }, label = { Text("Password") },
                    singleLine = true, isError = wrong,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    supportingText = { if (wrong) Text("That password did not work. Try again.") },
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSubmit(pw) }, enabled = pw.isNotEmpty()) { Text("Unlock") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun SortDialog(s: UiState, vm: MainViewModel) {
    AlertDialog(
        onDismissRequest = vm::dismissDialog,
        title = { Text("Sort and view") },
        text = {
            Column {
                SortField.values().forEach { f ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.setSort(f, s.sort.ascending) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = s.sort.field == f, onClick = { vm.setSort(f, s.sort.ascending) })
                        Text(f.label)
                    }
                }
                SwitchRow("Descending", !s.sort.ascending) { vm.setSort(s.sort.field, !it) }
                SwitchRow("Show hidden files", s.showHidden) { vm.setShowHidden(it) }
                SwitchRow("Dark theme", s.darkTheme) { vm.setDark(it) }
                Text("Accent colour", Modifier.padding(top = 14.dp, bottom = 8.dp), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Accent.values().forEachIndexed { i, a ->
                        Box(
                            Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(a.dark)
                                .border(if (s.accent == i) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                .clickable { vm.setAccent(i) },
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = vm::dismissDialog) { Text("Done") } },
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun FolderPickerDialog(start: File, roots: List<StorageRoot>, onDismiss: () -> Unit, onPick: (File) -> Unit) {
    var dir by remember { mutableStateOf(start) }
    val dirs = remember(dir) {
        dir.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") }?.sortedBy { it.name.lowercase() } ?: emptyList()
    }
    val atRoot = roots.any { it.path.absolutePath == dir.absolutePath }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose destination") },
        text = {
            Column {
                Text(dir.path, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyColumn(Modifier.heightIn(max = 320.dp).padding(top = 8.dp)) {
                    if (!atRoot && dir.parentFile != null) {
                        item {
                            PickerRow(Icons.Default.ArrowUpward, "..") { dir = dir.parentFile ?: dir }
                        }
                    }
                    items(dirs, key = { it.absolutePath }) { d ->
                        PickerRow(Icons.Default.Folder, d.name) { dir = d }
                    }
                    if (dirs.isEmpty()) {
                        item { Text("No subfolders", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onPick(dir) }) { Text("Extract here") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun PickerRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun ProgressDialog(p: OperationProgress, onCancel: () -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text(p.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (p.percent < 0) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(progress = { p.percent / 100f }, modifier = Modifier.fillMaxWidth())
                }
                Row {
                    Text(if (p.percent < 0) "Working..." else "${p.percent}%", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                    if (p.speedBytesPerSec > 0) Text("${formatSize(p.speedBytesPerSec)}/s", style = MaterialTheme.typography.bodyMedium)
                }
                if (p.currentFile.isNotEmpty()) {
                    Text(
                        p.currentFile, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}
