package dev.archivex.app.archive

import com.github.junrar.Archive
import com.github.junrar.exception.UnsupportedRarV5Exception
import dev.archivex.app.model.CancelToken
import dev.archivex.app.model.OperationCancelled
import dev.archivex.app.model.OperationProgress
import dev.archivex.app.model.ProgressReporter
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.exception.ZipException
import net.lingala.zip4j.io.outputstream.ZipOutputStream
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod
import net.lingala.zip4j.model.enums.CompressionLevel as ZipLevel
import org.apache.commons.compress.PasswordRequiredException
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZMethod
import org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.apache.commons.compress.compressors.gzip.GzipParameters
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.tukaani.xz.LZMA2Options
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.file.Files

sealed class PasswordIssue(message: String) : Exception(message)
class PasswordRequired : PasswordIssue("Password required")
class WrongPassword : PasswordIssue("Wrong password")

data class EntryInfo(val path: String, val isDir: Boolean, val size: Long, val modified: Long)

enum class ArchiveFormat(val label: String, val ext: String, val supportsPassword: Boolean) {
    ZIP("ZIP", ".zip", true),
    SEVEN_Z("7Z", ".7z", false),
    TAR("TAR", ".tar", false),
    TAR_GZ("GZ", ".tar.gz", false),
}

/** [deflate] is used for ZIP/GZ (0-9). [lzma] is the LZMA2 preset for 7z, capped to keep memory use phone-friendly. */
enum class Level(val label: String, val deflate: Int, val lzma: Int) {
    STORE("Store", 0, 0),
    FASTEST("Fastest", 1, 1),
    NORMAL("Normal", 6, 5),
    MAXIMUM("Maximum", 8, 6),
    ULTRA("Ultra", 9, 7),
}

enum class Kind { ZIP, SEVEN_Z, RAR, TAR, TAR_GZ, TAR_BZ2, TAR_XZ, GZ, BZ2, XZ }

class ArchiveEngine {

    companion object {
        private const val BUF = 128 * 1024

        fun kindOf(file: File): Kind? {
            val n = file.name.lowercase()
            return when {
                n.endsWith(".tar.gz") || n.endsWith(".tgz") -> Kind.TAR_GZ
                n.endsWith(".tar.bz2") || n.endsWith(".tbz2") || n.endsWith(".tbz") -> Kind.TAR_BZ2
                n.endsWith(".tar.xz") || n.endsWith(".txz") -> Kind.TAR_XZ
                n.endsWith(".tar") -> Kind.TAR
                n.endsWith(".gz") -> Kind.GZ
                n.endsWith(".bz2") -> Kind.BZ2
                n.endsWith(".xz") -> Kind.XZ
                n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".apk") || n.endsWith(".cbz") || n.endsWith(".aar") -> Kind.ZIP
                n.endsWith(".7z") -> Kind.SEVEN_Z
                n.endsWith(".rar") || n.endsWith(".cbr") -> Kind.RAR
                else -> null
            }
        }

        fun baseName(name: String): String {
            val n = name.lowercase()
            for (s in listOf(".tar.gz", ".tar.bz2", ".tar.xz")) if (n.endsWith(s)) return name.dropLast(s.length)
            return name.substringBeforeLast('.', name)
        }

        fun norm(path: String): String = path.replace('\\', '/').trim('/')

        private fun matches(path: String, sel: Set<String>?): Boolean =
            sel == null || sel.any { path == it || path.startsWith("$it/") }
    }

    // ------------------------------------------------------------------ LIST

    fun list(file: File, password: String?): List<EntryInfo> {
        val kind = kindOf(file) ?: throw IOException("Unsupported archive type")
        try {
            return when (kind) {
                Kind.ZIP -> ZipFile(file).fileHeaders.map {
                    EntryInfo(norm(it.fileName), it.isDirectory, it.uncompressedSize, it.lastModifiedTimeEpoch)
                }
                Kind.SEVEN_Z -> open7z(file, password).use { sz ->
                    sz.entries.map {
                        EntryInfo(norm(it.name ?: ""), it.isDirectory, it.size, if (it.hasLastModifiedDate) it.lastModifiedDate.time else 0L)
                    }
                }
                Kind.RAR -> openRar(file, password).use { a ->
                    a.fileHeaders.map {
                        EntryInfo(norm(it.fileName), it.isDirectory, it.fullUnpackSize, it.mTime?.time ?: 0L)
                    }
                }
                Kind.TAR, Kind.TAR_GZ, Kind.TAR_BZ2, Kind.TAR_XZ -> {
                    val out = ArrayList<EntryInfo>()
                    openTarStream(file, kind) { }.use { tin ->
                        var e = tin.nextTarEntry
                        while (e != null) {
                            out += EntryInfo(norm(e.name), e.isDirectory, e.size, e.lastModifiedDate?.time ?: 0L)
                            e = tin.nextTarEntry
                        }
                    }
                    out
                }
                Kind.GZ, Kind.BZ2, Kind.XZ -> listOf(EntryInfo(baseName(file.name), false, -1L, file.lastModified()))
            }.filter { it.path.isNotEmpty() }
        } catch (e: PasswordRequiredException) {
            throw PasswordRequired()
        }
    }

    // --------------------------------------------------------------- EXTRACT

    /**
     * Extracts [archive] into [destDir]. [selected] holds normalized entry paths (folders include their
     * children); null extracts everything. Blocking: call from a background thread.
     */
    fun extract(
        archive: File,
        destDir: File,
        password: String?,
        selected: Set<String>?,
        token: CancelToken,
        sink: (OperationProgress) -> Unit,
    ) {
        val kind = kindOf(archive) ?: throw IOException("Unsupported archive type")
        destDir.mkdirs()
        try {
            when (kind) {
                Kind.ZIP -> extractZip(archive, destDir, password, selected, token, sink)
                Kind.SEVEN_Z -> extract7z(archive, destDir, password, selected, token, sink)
                Kind.RAR -> extractRar(archive, destDir, password, selected, token, sink)
                Kind.TAR, Kind.TAR_GZ, Kind.TAR_BZ2, Kind.TAR_XZ -> extractTar(archive, kind, destDir, selected, token, sink)
                Kind.GZ, Kind.BZ2, Kind.XZ -> extractSingle(archive, kind, destDir, token, sink)
            }
        } catch (e: PasswordIssue) {
            throw e
        } catch (e: OperationCancelled) {
            throw e
        } catch (e: PasswordRequiredException) {
            throw PasswordRequired()
        } catch (e: Exception) {
            if (token.cancelled) throw OperationCancelled()
            if (password != null && looksLikeBadPassword(e)) throw WrongPassword()
            throw e
        }
    }

    private fun looksLikeBadPassword(e: Exception): Boolean {
        val m = (e.message ?: "").lowercase()
        return "password" in m || "checksum" in m || "crc" in m
    }

    private fun extractZip(file: File, dest: File, pw: String?, sel: Set<String>?, token: CancelToken, sink: (OperationProgress) -> Unit) {
        val zf = if (pw == null) ZipFile(file) else ZipFile(file, pw.toCharArray())
        val headers = zf.fileHeaders.filter { matches(norm(it.fileName), sel) }
        if (pw == null && headers.any { !it.isDirectory && it.isEncrypted }) throw PasswordRequired()
        val total = headers.filter { !it.isDirectory }.sumOf { it.uncompressedSize }
        val rep = ProgressReporter("Extracting ${file.name}", total, token, sink)
        try {
            for (h in headers) {
                token.check()
                val name = norm(h.fileName)
                if (name.isEmpty()) continue
                val target = safeTarget(dest, name)
                if (h.isDirectory) { target.mkdirs(); continue }
                rep.file(name)
                writeFile(target, h.lastModifiedTimeEpoch) { out ->
                    zf.getInputStream(h).use { ins -> pump(ins, out, rep) }
                }
            }
        } catch (e: ZipException) {
            if (pw != null && (e.type == ZipException.Type.WRONG_PASSWORD || e.type == ZipException.Type.CHECKSUM_MISMATCH)) throw WrongPassword()
            throw e
        }
    }

    private fun open7z(file: File, pw: String?): SevenZFile =
        try {
            if (pw == null) SevenZFile(file) else SevenZFile(file, pw.toCharArray())
        } catch (e: PasswordRequiredException) {
            throw PasswordRequired()
        }

    private fun extract7z(file: File, dest: File, pw: String?, sel: Set<String>?, token: CancelToken, sink: (OperationProgress) -> Unit) {
        open7z(file, pw).use { sz ->
            val total = sz.entries.filter { !it.isDirectory && matches(norm(it.name ?: ""), sel) }.sumOf { it.size }
            val rep = ProgressReporter("Extracting ${file.name}", total, token, sink)
            val buf = ByteArray(BUF)
            var e = sz.nextEntry
            while (e != null) {
                token.check()
                val name = norm(e.name ?: "")
                if (name.isNotEmpty() && matches(name, sel)) {
                    val target = safeTarget(dest, name)
                    if (e.isDirectory) {
                        target.mkdirs()
                    } else {
                        rep.file(name)
                        val modified = if (e.hasLastModifiedDate) e.lastModifiedDate.time else 0L
                        writeFile(target, modified) { out ->
                            while (true) {
                                val n = sz.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                rep.add(n.toLong())
                            }
                        }
                    }
                }
                e = sz.nextEntry
            }
        }
    }

    private fun openRar(file: File, pw: String?): Archive =
        try {
            if (pw == null) Archive(file) else Archive(file, pw)
        } catch (e: UnsupportedRarV5Exception) {
            throw IOException("RAR5 archives are not supported by this build (RAR 2.x-4.x only).")
        }

    private fun extractRar(file: File, dest: File, pw: String?, sel: Set<String>?, token: CancelToken, sink: (OperationProgress) -> Unit) {
        openRar(file, pw).use { a ->
            val headers = a.fileHeaders.filter { matches(norm(it.fileName), sel) }
            if (pw == null && headers.any { !it.isDirectory && it.isEncrypted }) throw PasswordRequired()
            val total = headers.filter { !it.isDirectory }.sumOf { it.fullUnpackSize }
            val rep = ProgressReporter("Extracting ${file.name}", total, token, sink)
            for (h in headers) {
                token.check()
                val name = norm(h.fileName)
                if (name.isEmpty()) continue
                val target = safeTarget(dest, name)
                if (h.isDirectory) { target.mkdirs(); continue }
                rep.file(name)
                writeFile(target, h.mTime?.time ?: 0L) { out ->
                    a.extractFile(h, CountingOutputStream(out) { rep.add(it.toLong()) })
                }
            }
        }
    }

    private fun extractTar(file: File, kind: Kind, dest: File, sel: Set<String>?, token: CancelToken, sink: (OperationProgress) -> Unit) {
        // Stream formats: progress is measured in compressed bytes read from disk.
        val rep = ProgressReporter("Extracting ${file.name}", file.length(), token, sink)
        openTarStream(file, kind) { rep.add(it) }.use { tin ->
            var e = tin.nextTarEntry
            while (e != null) {
                token.check()
                val name = norm(e.name)
                if (name.isNotEmpty() && matches(name, sel) && !e.isSymbolicLink && !e.isLink) {
                    val target = safeTarget(dest, name)
                    if (e.isDirectory) {
                        target.mkdirs()
                    } else {
                        rep.file(name)
                        writeFile(target, e.lastModifiedDate?.time ?: 0L) { out -> pump(tin, out, null) }
                    }
                }
                e = tin.nextTarEntry
            }
        }
    }

    private fun extractSingle(file: File, kind: Kind, dest: File, token: CancelToken, sink: (OperationProgress) -> Unit) {
        val rep = ProgressReporter("Extracting ${file.name}", file.length(), token, sink)
        val raw = CountingInputStream(BufferedInputStream(FileInputStream(file), BUF)) { rep.add(it) }
        val dec: InputStream = when (kind) {
            Kind.GZ -> GzipCompressorInputStream(raw, true)
            Kind.BZ2 -> BZip2CompressorInputStream(raw)
            else -> XZCompressorInputStream(raw)
        }
        val name = baseName(file.name).ifEmpty { "output" }
        val target = safeTarget(dest, name)
        rep.file(name)
        dec.use { ins -> writeFile(target, file.lastModified()) { out -> pump(ins, out, null) } }
    }

    private fun openTarStream(file: File, kind: Kind, onRead: (Long) -> Unit): TarArchiveInputStream {
        val raw = CountingInputStream(BufferedInputStream(FileInputStream(file), BUF), onRead)
        val dec: InputStream = when (kind) {
            Kind.TAR_GZ -> GzipCompressorInputStream(raw, true)
            Kind.TAR_BZ2 -> BZip2CompressorInputStream(raw)
            Kind.TAR_XZ -> XZCompressorInputStream(raw)
            else -> raw
        }
        return TarArchiveInputStream(dec)
    }

    // ---------------------------------------------------------------- CREATE

    private data class Item(val file: File, val name: String, val isDir: Boolean)

    fun create(
        sources: List<File>,
        output: File,
        format: ArchiveFormat,
        level: Level,
        password: String?,
        token: CancelToken,
        sink: (OperationProgress) -> Unit,
    ) {
        val tmp = File(output.parentFile, output.name + ".part")
        val items = collect(sources, tmp)
        val total = items.filter { !it.isDir }.sumOf { it.file.length() }
        val rep = ProgressReporter("Compressing ${output.name}", total, token, sink)
        try {
            when (format) {
                ArchiveFormat.ZIP -> writeZip(tmp, items, level, password, rep)
                ArchiveFormat.SEVEN_Z -> write7z(tmp, items, level, rep)
                ArchiveFormat.TAR -> writeTar(tmp, items, false, level, rep)
                ArchiveFormat.TAR_GZ -> writeTar(tmp, items, true, level, rep)
            }
            if (!tmp.renameTo(output)) throw IOException("Could not create ${output.name}")
        } catch (e: Throwable) {
            tmp.delete()
            if (token.cancelled) throw OperationCancelled()
            throw e
        }
    }

    private fun collect(sources: List<File>, exclude: File): List<Item> {
        val out = ArrayList<Item>()
        val excluded = exclude.absoluteFile
        fun walk(f: File, name: String) {
            if (f.absoluteFile == excluded) return
            if (Files.isSymbolicLink(f.toPath())) return
            if (f.isDirectory) {
                out += Item(f, name, true)
                f.listFiles()?.sortedBy { it.name }?.forEach { walk(it, "$name/${it.name}") }
            } else if (f.isFile) {
                out += Item(f, name, false)
            }
        }
        sources.forEach { walk(it, it.name) }
        return out
    }

    private fun zipLevel(l: Level): ZipLevel = when (l) {
        Level.STORE -> ZipLevel.NO_COMPRESSION
        Level.FASTEST -> ZipLevel.FASTEST
        Level.NORMAL -> ZipLevel.NORMAL
        Level.MAXIMUM -> ZipLevel.MAXIMUM
        Level.ULTRA -> ZipLevel.ULTRA
    }

    private fun writeZip(tmp: File, items: List<Item>, level: Level, password: String?, rep: ProgressReporter) {
        val out = FileOutputStream(tmp)
        val zos = if (password.isNullOrEmpty()) ZipOutputStream(out) else ZipOutputStream(out, password.toCharArray())
        zos.use {
            for (item in items) {
                rep.file(item.name)
                val p = ZipParameters()
                p.setFileNameInZip(if (item.isDir) item.name + "/" else item.name)
                p.setLastModifiedFileTime(item.file.lastModified())
                p.setCompressionMethod(if (level == Level.STORE) CompressionMethod.STORE else CompressionMethod.DEFLATE)
                p.setCompressionLevel(zipLevel(level))
                if (!item.isDir) {
                    p.setEntrySize(item.file.length())
                    if (!password.isNullOrEmpty()) {
                        p.setEncryptFiles(true)
                        p.setEncryptionMethod(EncryptionMethod.AES)
                        p.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256)
                    }
                }
                zos.putNextEntry(p)
                if (!item.isDir) FileInputStream(item.file).use { pump(it, zos, rep) }
                zos.closeEntry()
            }
        }
    }

    private fun write7z(tmp: File, items: List<Item>, level: Level, rep: ProgressReporter) {
        SevenZOutputFile(tmp).use { sz ->
            val cfg = if (level == Level.STORE) {
                SevenZMethodConfiguration(SevenZMethod.COPY)
            } else {
                SevenZMethodConfiguration(SevenZMethod.LZMA2, LZMA2Options(level.lzma))
            }
            sz.setContentMethods(listOf(cfg))
            val buf = ByteArray(BUF)
            for (item in items) {
                rep.file(item.name)
                val entry = sz.createArchiveEntry(item.file, item.name)
                sz.putArchiveEntry(entry)
                if (!item.isDir) {
                    FileInputStream(item.file).use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            sz.write(buf, 0, n)
                            rep.add(n.toLong())
                        }
                    }
                }
                sz.closeArchiveEntry()
            }
            sz.finish()
        }
    }

    private fun writeTar(tmp: File, items: List<Item>, gzip: Boolean, level: Level, rep: ProgressReporter) {
        val base: OutputStream = BufferedOutputStream(FileOutputStream(tmp), BUF)
        val os: OutputStream = if (gzip) {
            val params = GzipParameters()
            params.compressionLevel = level.deflate
            GzipCompressorOutputStream(base, params)
        } else base
        TarArchiveOutputStream(os).use { tar ->
            tar.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
            tar.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX)
            for (item in items) {
                rep.file(item.name)
                val entry = TarArchiveEntry(if (item.isDir) item.name + "/" else item.name)
                if (!item.isDir) entry.size = item.file.length()
                entry.setModTime(item.file.lastModified())
                tar.putArchiveEntry(entry)
                if (!item.isDir) FileInputStream(item.file).use { pump(it, tar, rep) }
                tar.closeArchiveEntry()
            }
            tar.finish()
        }
    }

    // --------------------------------------------------------------- HELPERS

    private fun safeTarget(dest: File, name: String): File {
        val t = File(dest, name)
        val destPath = dest.canonicalPath
        val tp = t.canonicalPath
        if (tp != destPath && !tp.startsWith(destPath + File.separator)) throw IOException("Blocked unsafe path: $name")
        return t
    }

    private fun writeFile(target: File, modified: Long, writer: (OutputStream) -> Unit) {
        target.parentFile?.mkdirs()
        try {
            FileOutputStream(target).use { out -> writer(out) }
        } catch (e: Throwable) {
            target.delete()
            throw e
        }
        if (modified > 0) target.setLastModified(modified)
    }

    private fun pump(ins: InputStream, out: OutputStream, rep: ProgressReporter?) {
        val buf = ByteArray(BUF)
        while (true) {
            val n = ins.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            rep?.add(n.toLong())
        }
    }

    private class CountingInputStream(inner: InputStream, private val onRead: (Long) -> Unit) : FilterInputStream(inner) {
        override fun read(): Int {
            val b = super.read()
            if (b >= 0) onRead(1)
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) onRead(n.toLong())
            return n
        }
    }

    private class CountingOutputStream(private val out: OutputStream, private val onWrite: (Int) -> Unit) : OutputStream() {
        override fun write(b: Int) { out.write(b); onWrite(1) }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); onWrite(len) }
        override fun flush() = out.flush()
        override fun close() = out.close()
    }
}
