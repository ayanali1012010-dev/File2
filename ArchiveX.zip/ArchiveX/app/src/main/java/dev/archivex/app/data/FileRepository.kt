package dev.archivex.app.data

import dev.archivex.app.model.CancelToken
import dev.archivex.app.model.FileItem
import dev.archivex.app.model.FileTypes
import dev.archivex.app.model.OperationCancelled
import dev.archivex.app.model.OperationProgress
import dev.archivex.app.model.ProgressReporter
import dev.archivex.app.model.SortOption
import dev.archivex.app.model.Sorter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

data class FileProps(
    val name: String,
    val path: String,
    val kind: String,
    val size: Long,
    val files: Int,
    val folders: Int,
    val modified: Long,
    val readable: Boolean,
    val writable: Boolean,
    val hidden: Boolean,
)

/**
 * Disk operations. Everything except [list] is blocking and must be called from a background
 * dispatcher (the ViewModel wraps these calls in Dispatchers.IO).
 */
class FileRepository {

    suspend fun list(dir: File, sort: SortOption, showHidden: Boolean): List<FileItem> =
        withContext(Dispatchers.IO) {
            val files = dir.listFiles() ?: throw IOException("Cannot read ${dir.path}. Check storage access.")
            val items = files.asSequence()
                .filter { showHidden || !it.name.startsWith(".") }
                .map { toItem(it) }
                .toList()
            Sorter.sort(items, sort)
        }

    fun toItem(f: File): FileItem {
        val dir = f.isDirectory
        return FileItem(f.absolutePath, f.name, dir, if (dir) 0L else f.length(), f.lastModified(), FileTypes.of(f.name, dir), f)
    }

    fun createFolder(parent: File, name: String): File {
        validateName(name)
        val target = File(parent, name)
        if (target.exists()) throw IOException("\"$name\" already exists")
        if (!target.mkdirs()) throw IOException("Could not create folder \"$name\"")
        return target
    }

    fun rename(file: File, newName: String): File {
        validateName(newName)
        val target = File(file.parentFile, newName)
        if (target.exists()) throw IOException("\"$newName\" already exists")
        if (!file.renameTo(target)) throw IOException("Could not rename \"${file.name}\"")
        return target
    }

    /** Returns the number of items that could not be deleted. */
    fun delete(files: List<File>, token: CancelToken): Int {
        var failed = 0
        for (f in files) {
            token.check()
            if (!f.deleteRecursively()) failed++
        }
        return failed
    }

    fun paste(
        files: List<File>,
        destDir: File,
        move: Boolean,
        token: CancelToken,
        sink: (OperationProgress) -> Unit,
    ): Int {
        val total = files.sumOf { sizeOf(it) }
        val rep = ProgressReporter(if (move) "Moving" else "Copying", total, token, sink)
        val destCanon = destDir.canonicalFile
        var count = 0
        for (src in files) {
            token.check()
            val srcCanon = src.canonicalFile
            if (src.isDirectory && (destCanon == srcCanon || destCanon.path.startsWith(srcCanon.path + File.separator))) {
                throw IOException("Cannot put \"${src.name}\" inside itself")
            }
            if (move && srcCanon.parentFile == destCanon) continue
            val target = uniqueFile(destDir, src.name)
            rep.file(src.name)
            if (move) {
                val size = sizeOf(src)
                if (src.renameTo(target)) {
                    rep.add(size)
                } else {
                    copyRecursive(src, target, rep)
                    src.deleteRecursively()
                }
            } else {
                copyRecursive(src, target, rep)
            }
            count++
        }
        return count
    }

    private fun copyRecursive(src: File, dst: File, rep: ProgressReporter) {
        if (src.isDirectory) {
            if (!dst.exists() && !dst.mkdirs()) throw IOException("Cannot create ${dst.name}")
            src.listFiles()?.forEach { copyRecursive(it, File(dst, it.name), rep) }
            return
        }
        rep.file(src.name)
        try {
            FileInputStream(src).use { input ->
                FileOutputStream(dst).use { output ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        rep.add(n.toLong())
                    }
                }
            }
        } catch (e: OperationCancelled) {
            dst.delete()
            throw e
        } catch (e: IOException) {
            dst.delete()
            throw e
        }
        dst.setLastModified(src.lastModified())
    }

    fun sizeOf(f: File): Long =
        if (f.isDirectory) f.walkTopDown().filter { it.isFile }.sumOf { it.length() } else f.length()

    fun uniqueFile(dir: File, name: String): File {
        var candidate = File(dir, name)
        if (!candidate.exists()) return candidate
        val lower = name.lowercase()
        val multi = listOf(".tar.gz", ".tar.bz2", ".tar.xz").firstOrNull { lower.endsWith(it) }
        val ext = multi ?: name.substringAfterLast('.', "").let { if (it.isEmpty() || it == name) "" else ".$it" }
        val base = name.dropLast(ext.length)
        var i = 1
        while (candidate.exists()) {
            candidate = File(dir, "$base ($i)$ext")
            i++
        }
        return candidate
    }

    fun properties(f: File): FileProps {
        var files = 0
        var folders = 0
        var size = 0L
        if (f.isDirectory) {
            f.walkTopDown().drop(1).forEach {
                if (it.isDirectory) folders++ else { files++; size += it.length() }
            }
        } else {
            size = f.length()
        }
        val type = FileTypes.of(f.name, f.isDirectory).name.lowercase().replaceFirstChar { it.uppercase() }
        return FileProps(f.name, f.absolutePath, type, size, files, folders, f.lastModified(), f.canRead(), f.canWrite(), f.isHidden)
    }

    private fun validateName(name: String) {
        if (name.isBlank()) throw IOException("Name cannot be empty")
        if (name.contains('/') || name.contains('\u0000')) throw IOException("Name contains invalid characters")
        if (name == "." || name == "..") throw IOException("Invalid name")
    }
}
