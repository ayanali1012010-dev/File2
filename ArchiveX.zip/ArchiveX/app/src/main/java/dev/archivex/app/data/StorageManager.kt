package dev.archivex.app.data

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.io.File

data class StorageRoot(val label: String, val path: File)

class StorageManager(private val context: Context) {

    fun hasAllFilesAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }

    /** Settings screen where the user grants "All files access" (Android 11+). */
    fun allFilesAccessIntent(): Intent {
        val uri = Uri.parse("package:${context.packageName}")
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri)
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)
        }
    }

    fun roots(): List<StorageRoot> {
        val list = mutableListOf<StorageRoot>()
        val primary = Environment.getExternalStorageDirectory()
        list += StorageRoot("Internal storage", primary)
        context.getExternalFilesDirs(null).filterNotNull().forEach { d ->
            val idx = d.absolutePath.indexOf("/Android/data")
            if (idx > 0) {
                val root = File(d.absolutePath.substring(0, idx))
                if (root.absolutePath != primary.absolutePath && root.exists() && list.none { it.path.absolutePath == root.absolutePath }) {
                    list += StorageRoot("SD card (${root.name})", root)
                }
            }
        }
        list += StorageRoot("Device root (/)", File("/"))
        return list
    }
}
