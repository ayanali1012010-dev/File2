package dev.archivex.app.ui

import androidx.activity.compose.BackHandler
import android.graphics.BitmapFactory
import android.os.StatFs
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.archivex.app.archive.ArchiveEngine
import dev.archivex.app.archive.ArchiveFormat
import dev.archivex.app.model.FileItem
import dev.archivex.app.model.FileType
import dev.archivex.app.model.formatSize
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: MainViewModel, onGrantAccess: () -> Unit, onExit: () -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(s.message) {
        val m = s.message
        if (m != null) {
            snackbar.showSnackbar(m)
            vm.messageShown()
        }
    }

    BackHandler { if (!vm.onBack()) onExit() }

    if (!s.hasPermission) {
        PermissionScreen(onGrantAccess)
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column {
                MainTopBar(s, vm)
                Breadcrumbs(s, vm)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        },
        bottomBar = {
            val cb = s.clipboard
            if (cb != null && s.archive == null) {
                Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, tonalElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "${cb.files.size} item(s) to ${if (cb.move) "move" else "copy"}",
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        TextButton(onClick = vm::clearClipboard) { Text("Clear") }
                        Button(onClick = vm::paste) { Text("Paste here") }
                    }
                }
            }
        },
        floatingActionButton = {
            if (s.archive == null && !s.selecting) {
                ExtendedFloatingActionButton(
                    onClick = { vm.showDialog(UiDialog.NewFolder) },
                    icon = { Icon(Icons.Default.CreateNewFolder, null) },
                    text = { Text("New folder") },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (s.items.isEmpty() && !s.loading) {
                Text(
                    if (s.archive != null) "This folder is empty" else "Nothing here yet",
                    Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
                if (s.archive == null) item(key = "header") { HomeHeader(s, vm) }
                items(s.items, key = { it.key }) { item ->
                    FileRow(
                        item = item,
                        selected = item.key in s.selection,
                        selecting = s.selecting,
                        onClick = { vm.onItemClick(item) },
                        onLong = { vm.onItemLongClick(item) },
                    )
                }
            }
            if (s.loading) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
        }
    }

    s.sheet?.let { ActionSheet(s, it, vm) }
    DialogHost(s, vm)
    s.progress?.let { ProgressDialog(it, vm::cancelOperation) }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Default.FolderOpen, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.size(20.dp))
        Text("Allow access to your files", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.size(8.dp))
        Text(
            "ArchiveX needs access to all files to browse storage, create archives and extract them next to your data.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.size(24.dp))
        Button(onClick = onGrant) { Text("Grant access") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainTopBar(s: UiState, vm: MainViewModel) {
    var menu by remember { mutableStateOf(false) }
    val inArchive = s.archive != null

    if (s.selecting) {
        TopAppBar(
            title = { Text("${s.selection.size} selected") },
            navigationIcon = { IconButton(onClick = vm::clearSelection) { Icon(Icons.Default.Close, "Cancel selection") } },
            actions = {
                IconButton(onClick = vm::selectAll) { Icon(Icons.Default.SelectAll, "Select all") }
                if (!inArchive) {
                    IconButton(onClick = { vm.copyToClipboard(vm.selectedItems(), false) }, enabled = s.selection.isNotEmpty()) {
                        Icon(Icons.Default.ContentCopy, "Copy")
                    }
                    IconButton(onClick = { vm.copyToClipboard(vm.selectedItems(), true) }, enabled = s.selection.isNotEmpty()) {
                        Icon(Icons.Default.ContentCut, "Cut")
                    }
                    IconButton(
                        onClick = { vm.showDialog(UiDialog.Delete(vm.selectedItems())) },
                        enabled = s.selection.isNotEmpty(),
                    ) { Icon(Icons.Default.Delete, "Delete") }
                }
                IconButton(onClick = vm::openSheetForSelection, enabled = s.selection.isNotEmpty()) {
                    Icon(Icons.Default.MoreVert, "More actions")
                }
            },
        )
        return
    }

    TopAppBar(
        title = {
            Text(
                if (inArchive) s.archive!!.file.name else s.currentDir.name.ifEmpty { "/" },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        },
        navigationIcon = {
            if (inArchive) IconButton(onClick = vm::closeArchiveNow) { Icon(Icons.Default.ArrowBack, "Close archive") }
        },
        actions = {
            if (inArchive) {
                IconButton(onClick = { vm.extractFromSession(null, false) }) { Icon(Icons.Default.Unarchive, "Extract all") }
            }
            IconButton(onClick = { vm.showDialog(UiDialog.SortAndView) }) { Icon(Icons.Default.Sort, "Sort and view") }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Select items") },
                        leadingIcon = { Icon(Icons.Default.CheckBox, null) },
                        onClick = { menu = false; vm.startSelecting() },
                    )
                    if (!inArchive) {
                        DropdownMenuItem(
                            text = { Text("New folder") },
                            leadingIcon = { Icon(Icons.Default.CreateNewFolder, null) },
                            onClick = { menu = false; vm.showDialog(UiDialog.NewFolder) },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Refresh") },
                        leadingIcon = { Icon(Icons.Default.Refresh, null) },
                        onClick = { menu = false; vm.reload() },
                    )
                    HorizontalDivider()
                    s.roots.forEach { root ->
                        DropdownMenuItem(
                            text = { Text(root.label) },
                            leadingIcon = { Icon(Icons.Default.Storage, null) },
                            onClick = { menu = false; vm.navigate(root.path) },
                        )
                    }
                }
            }
        },
    )
}

private class Crumb(val label: String, val onClick: () -> Unit)

private fun buildCrumbs(s: UiState, vm: MainViewModel): List<Crumb> {
    val out = ArrayList<Crumb>()
    val session = s.archive
    if (session != null) {
        out += Crumb(session.file.name) { vm.showArchiveFolder("") }
        var acc = ""
        if (session.innerPath.isNotEmpty()) {
            session.innerPath.split('/').forEach { seg ->
                acc = if (acc.isEmpty()) seg else "$acc/$seg"
                val target = acc
                out += Crumb(seg) { vm.showArchiveFolder(target) }
            }
        }
        return out
    }
    val dir = s.currentDir.absoluteFile
    val root = s.roots
        .filter { dir.path == it.path.path || dir.path.startsWith(it.path.path.trimEnd('/') + "/") }
        .maxByOrNull { it.path.path.length }
    val base = root?.path ?: File("/")
    out += Crumb(root?.label ?: "/") { vm.navigate(base) }
    val rel = dir.path.removePrefix(base.path).trim('/')
    var cur = base
    if (rel.isNotEmpty()) {
        rel.split('/').forEach { seg ->
            cur = File(cur, seg)
            val target = cur
            out += Crumb(seg) { vm.navigate(target) }
        }
    }
    return out
}

@Composable
private fun Breadcrumbs(s: UiState, vm: MainViewModel) {
    val crumbs = buildCrumbs(s, vm)
    val scroll = rememberScrollState()
    LaunchedEffect(crumbs.size, s.currentDir, s.archive?.innerPath) { scroll.animateScrollTo(scroll.maxValue) }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(scroll).padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        crumbs.forEachIndexed { i, c ->
            val last = i == crumbs.lastIndex
            Text(
                c.label,
                Modifier.clip(RoundedCornerShape(6.dp)).clickable(onClick = c.onClick).padding(horizontal = 8.dp, vertical = 8.dp),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (last) FontWeight.Bold else FontWeight.Normal,
                color = if (last) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
            )
            if (!last) {
                Icon(Icons.Default.ChevronRight, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.outline)
            }
        }
    }
}

private fun iconFor(type: FileType): Pair<ImageVector, Color> = when (type) {
    FileType.FOLDER -> Icons.Default.Folder to Color(0xFFFFCA28)
    FileType.IMAGE -> Icons.Default.Image to Color(0xFFBA68C8)
    FileType.VIDEO -> Icons.Default.Movie to Color(0xFFEF5350)
    FileType.AUDIO -> Icons.Default.MusicNote to Color(0xFF42A5F5)
    FileType.APK -> Icons.Default.Android to Color(0xFF66BB6A)
    FileType.DOCUMENT -> Icons.Default.Description to Color(0xFF26A69A)
    FileType.ARCHIVE -> Icons.Default.Archive to Color(0xFFFFA726)
    FileType.OTHER -> Icons.Default.InsertDriveFile to Color(0xFF90A4AE)
}

@Composable
private fun HomeHeader(s: UiState, vm: MainViewModel) {
    val root = s.roots
        .filter { s.currentDir.path == it.path.path || s.currentDir.path.startsWith(it.path.path.trimEnd('/') + "/") }
        .maxByOrNull { it.path.path.length } ?: s.roots.first()
    val stats = remember(root.path.path, s.items) {
        try {
            val st = StatFs(root.path.path)
            st.totalBytes to st.availableBytes
        } catch (e: Exception) { null }
    }
    val cs = MaterialTheme.colorScheme
    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
        if (stats != null && stats.first > 0) {
            val total = stats.first
            val free = stats.second
            val used = total - free
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(cs.primaryContainer, cs.surfaceContainerHigh)))
                    .padding(18.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Storage, null, tint = cs.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(root.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(14.dp))
                LinearProgressIndicator(
                    progress = { (used.toFloat() / total.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                    color = cs.primary,
                    trackColor = cs.background.copy(alpha = 0.45f),
                )
                Spacer(Modifier.height(8.dp))
                Row {
                    Text("${formatSize(used)} used", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    Text("${formatSize(free)} free", style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        val base = s.roots.first().path
        val quick = listOf(
            Triple("Downloads", "Download", Icons.Default.Download),
            Triple("Camera", "DCIM", Icons.Default.PhotoCamera),
            Triple("Documents", "Documents", Icons.Default.Description),
            Triple("Music", "Music", Icons.Default.MusicNote),
            Triple("Pictures", "Pictures", Icons.Default.Image),
            Triple("Movies", "Movies", Icons.Default.Movie),
        ).filter { File(base, it.second).isDirectory }
        if (quick.isNotEmpty()) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                quick.forEach { (label, folder, icon) ->
                    AssistChip(
                        onClick = { vm.navigate(File(base, folder)) },
                        label = { Text(label) },
                        leadingIcon = { Icon(icon, null, Modifier.size(18.dp), tint = cs.primary) },
                    )
                }
            }
        }
    }
}

private fun decodeThumb(f: File): ImageBitmap? {
    if (f.length() > 40L * 1024 * 1024) return null
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, o)
    if (o.outWidth <= 0 || o.outHeight <= 0) return null
    var sample = 1
    while (o.outWidth / (sample * 2) >= 160 && o.outHeight / (sample * 2) >= 160) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    return BitmapFactory.decodeFile(f.path, opts)?.asImageBitmap()
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRow(item: FileItem, selected: Boolean, selecting: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val (icon, tint) = iconFor(item.type)
    val date = if (item.modified > 0) dateFormat.format(Date(item.modified)) else ""
    val subtitle = when {
        item.isDir -> date
        date.isEmpty() -> formatSize(item.size)
        else -> "${formatSize(item.size)}   $date"
    }
    val thumb by produceState<ImageBitmap?>(null, item.key) {
        val f = item.file
        value = if (item.type == FileType.IMAGE && f != null) withContext(Dispatchers.IO) { decodeThumb(f) } else null
    }
    val bg by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
        label = "rowBg",
    )
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 3.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (selecting) {
            Checkbox(checked = selected, onCheckedChange = { onClick() })
            Spacer(Modifier.width(4.dp))
        }
        Box(
            Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(tint.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center,
        ) {
            val bmp = thumb
            if (bmp != null) {
                Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium,
            )
            if (subtitle.isNotEmpty()) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (!selecting && item.isDir) {
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.outline)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ActionSheet(s: UiState, items: List<FileItem>, vm: MainViewModel) {
    val single = items.singleOrNull()
    val inArchive = s.archive != null
    val diskFile = single?.file
    val isArchiveFile = single != null && !single.isDir && diskFile != null && ArchiveEngine.kindOf(diskFile) != null
    val title = single?.name ?: "${items.size} items selected"

    ModalBottomSheet(onDismissRequest = vm::dismissSheet, containerColor = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Text(
                title,
                Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            fun act(block: () -> Unit): () -> Unit = { vm.dismissSheet(); block() }

            if (inArchive) {
                if (single != null) {
                    SheetRow(Icons.Default.FolderOpen, if (single.isDir) "Open" else "Preview", act { vm.onItemClick(single) })
                }
                SheetRow(Icons.Default.Unarchive, "Extract here", act { vm.extractFromSession(items, true) })
                SheetRow(Icons.Default.FolderZip, "Extract to...", act { vm.extractFromSession(items, false) })
            } else {
                if (single != null) {
                    SheetRow(Icons.Default.FolderOpen, "Open", act { vm.onItemClick(single) })
                }
                if (isArchiveFile && diskFile != null) {
                    SheetRow(Icons.Default.Unarchive, "Extract here", act { vm.extractHere(diskFile) })
                    SheetRow(Icons.Default.FolderZip, "Extract to ./${ArchiveEngine.baseName(diskFile.name)}/", act { vm.extractToNamedFolder(diskFile) })
                    SheetRow(Icons.Default.Folder, "Extract to...", act { vm.extractToPicker(diskFile) })
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
                SheetRow(Icons.Default.Archive, "Compress to .zip", act { vm.quickCompress(items, ArchiveFormat.ZIP) })
                SheetRow(Icons.Default.Archive, "Compress to .7z", act { vm.quickCompress(items, ArchiveFormat.SEVEN_Z) })
                SheetRow(Icons.Default.Lock, "Compress...", act { vm.showDialog(UiDialog.Compress(items)) })
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                SheetRow(Icons.Default.ContentCopy, "Copy", act { vm.copyToClipboard(items, false) })
                SheetRow(Icons.Default.ContentCut, "Cut", act { vm.copyToClipboard(items, true) })
                if (single != null) {
                    SheetRow(Icons.Default.DriveFileRenameOutline, "Rename", act { vm.showDialog(UiDialog.Rename(single)) })
                    SheetRow(Icons.Default.Info, "Details", act { vm.showProperties(single) })
                }
                SheetRow(Icons.Default.Delete, "Delete", act { vm.showDialog(UiDialog.Delete(items)) })
            }
        }
    }
}

@Composable
private fun SheetRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(18.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
