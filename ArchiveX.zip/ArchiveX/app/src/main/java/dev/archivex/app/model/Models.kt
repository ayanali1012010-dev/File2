package dev.archivex.app.model

import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

enum class FileType { FOLDER, IMAGE, VIDEO, AUDIO, APK, DOCUMENT, ARCHIVE, OTHER }

object FileTypes {
    private val images = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg")
    private val videos = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv", "m4v")
    private val audio = setOf("mp3", "wav", "flac", "ogg", "m4a", "aac", "opus", "wma", "amr")
    private val docs = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "rtf", "odt", "csv", "json", "xml", "html", "epub")
    private val archives = setOf("zip", "7z", "rar", "tar", "gz", "tgz", "bz2", "tbz2", "tbz", "xz", "txz", "iso", "cab", "jar", "cbz", "cbr", "aar")

    fun of(name: String, isDir: Boolean): FileType {
        if (isDir) return FileType.FOLDER
        val ext = name.lowercase().substringAfterLast('.', "")
        return when (ext) {
            "apk", "apks", "xapk" -> FileType.APK
            in archives -> FileType.ARCHIVE
            in images -> FileType.IMAGE
            in videos -> FileType.VIDEO
            in audio -> FileType.AUDIO
            in docs -> FileType.DOCUMENT
            else -> FileType.OTHER
        }
    }
}

/** A row in the file list. [file] is null for entries that live inside an archive. */
data class FileItem(
    val key: String,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val type: FileType,
    val file: File?,
)

enum class SortField(val label: String) { NAME("Name"), DATE("Date"), SIZE("Size"), TYPE("Type") }

data class SortOption(val field: SortField = SortField.NAME, val ascending: Boolean = true)

object Sorter {
    fun sort(items: List<FileItem>, opt: SortOption): List<FileItem> {
        val byName = Comparator<FileItem> { a, b -> a.name.compareTo(b.name, ignoreCase = true) }
        val base: Comparator<FileItem> = when (opt.field) {
            SortField.NAME -> byName
            SortField.DATE -> Comparator<FileItem> { a, b -> a.modified.compareTo(b.modified) }.then(byName)
            SortField.SIZE -> Comparator<FileItem> { a, b -> a.size.compareTo(b.size) }.then(byName)
            SortField.TYPE -> Comparator<FileItem> { a, b ->
                a.name.substringAfterLast('.', "").lowercase().compareTo(b.name.substringAfterLast('.', "").lowercase())
            }.then(byName)
        }
        val directed = if (opt.ascending) base else base.reversed()
        val foldersFirst = Comparator<FileItem> { a, b -> b.isDir.compareTo(a.isDir) }
        return items.sortedWith(foldersFirst.then(directed))
    }
}

data class OperationProgress(
    val title: String,
    /** 0..100, or -1 when the total is unknown. */
    val percent: Int,
    val currentFile: String,
    val speedBytesPerSec: Long,
)

class OperationCancelled : Exception("Cancelled")

class CancelToken {
    @Volatile
    var cancelled: Boolean = false
        private set

    fun cancel() { cancelled = true }
    fun check() { if (cancelled) throw OperationCancelled() }
}

class ProgressReporter(
    private val title: String,
    private val totalBytes: Long,
    val token: CancelToken,
    private val sink: (OperationProgress) -> Unit,
) {
    private val done = AtomicLong(0)
    private val startNs = System.nanoTime()
    @Volatile private var lastEmitNs = 0L
    @Volatile private var current = ""

    fun file(name: String) {
        token.check()
        current = name
        emit(true)
    }

    fun add(bytes: Long) {
        done.addAndGet(bytes)
        token.check()
        emit(false)
    }

    private fun emit(force: Boolean) {
        val now = System.nanoTime()
        if (!force && now - lastEmitNs < 100_000_000L) return
        lastEmitNs = now
        val elapsed = (now - startNs) / 1_000_000_000.0
        val d = done.get()
        val speed = if (elapsed > 0.2) (d / elapsed).toLong() else 0L
        val pct = if (totalBytes > 0) ((d * 100) / totalBytes).toInt().coerceIn(0, 100) else -1
        sink(OperationProgress(title, pct, current, speed))
    }
}

fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = bytes / 1024.0
    var i = 0
    while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
    return String.format(Locale.US, "%.1f %s", v, units[i])
}

fun defaultArchiveName(items: List<FileItem>): String {
    val one = items.singleOrNull()
    if (one != null) return if (one.isDir) one.name else one.name.substringBeforeLast('.', one.name)
    val parent = items.firstOrNull()?.file?.parentFile?.name
    return if (parent.isNullOrEmpty()) "Archive" else parent
}
