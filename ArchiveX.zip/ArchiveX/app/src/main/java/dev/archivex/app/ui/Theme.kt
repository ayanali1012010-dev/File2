package dev.archivex.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF66BB6A),
    onPrimary = Color(0xFF00270A),
    primaryContainer = Color(0xFF1F5A24),
    onPrimaryContainer = Color(0xFFCDEBCF),
    secondary = Color(0xFF8BC48E),
    onSecondary = Color(0xFF0B2A0E),
    background = Color(0xFF111312),
    onBackground = Color(0xFFE3E8E4),
    surface = Color(0xFF181B19),
    onSurface = Color(0xFFE3E8E4),
    surfaceVariant = Color(0xFF252A27),
    onSurfaceVariant = Color(0xFFA9B3AD),
    surfaceContainer = Color(0xFF1D211F),
    surfaceContainerHigh = Color(0xFF242926),
    surfaceContainerLow = Color(0xFF1A1D1B),
    outline = Color(0xFF3A423D),
    outlineVariant = Color(0xFF2C332F),
)

private val Light = lightColorScheme(
    primary = Color(0xFF2E7D32),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFC8E6C9),
    onPrimaryContainer = Color(0xFF0B2A0E),
    secondary = Color(0xFF4C7F50),
    background = Color(0xFFF6F8F6),
    onBackground = Color(0xFF181B19),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF181B19),
    surfaceVariant = Color(0xFFE3EAE4),
    onSurfaceVariant = Color(0xFF4A544E),
    surfaceContainer = Color(0xFFF0F4F0),
    surfaceContainerHigh = Color(0xFFE9EEE9),
    surfaceContainerLow = Color(0xFFF3F6F3),
    outline = Color(0xFF9AA59D),
    outlineVariant = Color(0xFFD0D8D2),
)

@Composable
fun ArchiveXTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
