package dev.archivex.app.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Selectable accent colours: [dark] is used on dark theme, [light] on light theme. */
enum class Accent(val label: String, val dark: Color, val light: Color, val darkContainer: Color, val lightContainer: Color) {
    GREEN("Green", Color(0xFF66BB6A), Color(0xFF2E7D32), Color(0xFF1F5A24), Color(0xFFC8E6C9)),
    BLUE("Blue", Color(0xFF64B5F6), Color(0xFF1565C0), Color(0xFF16477A), Color(0xFFBBDEFB)),
    PURPLE("Purple", Color(0xFFBA68C8), Color(0xFF7B1FA2), Color(0xFF52206B), Color(0xFFE1BEE7)),
    ORANGE("Orange", Color(0xFFFFB74D), Color(0xFFE65100), Color(0xFF6B3A00), Color(0xFFFFE0B2)),
    PINK("Pink", Color(0xFFF06292), Color(0xFFC2185B), Color(0xFF6E1F3C), Color(0xFFF8BBD0)),
}

private val Dark: ColorScheme = darkColorScheme(
    onPrimary = Color(0xFF0E0E0E),
    onPrimaryContainer = Color(0xFFF1F4F2),
    background = Color(0xFF0F1110),
    onBackground = Color(0xFFE3E8E4),
    surface = Color(0xFF181B19),
    onSurface = Color(0xFFE3E8E4),
    surfaceVariant = Color(0xFF252A27),
    onSurfaceVariant = Color(0xFFA9B3AD),
    surfaceContainer = Color(0xFF1D211F),
    surfaceContainerHigh = Color(0xFF242926),
    surfaceContainerLow = Color(0xFF1A1D1B),
    outline = Color(0xFF3A423D),
    outlineVariant = Color(0xFF2C332F),
)

private val Light: ColorScheme = lightColorScheme(
    onPrimary = Color(0xFFFFFFFF),
    onPrimaryContainer = Color(0xFF111111),
    background = Color(0xFFF6F8F6),
    onBackground = Color(0xFF181B19),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF181B19),
    surfaceVariant = Color(0xFFE3EAE4),
    onSurfaceVariant = Color(0xFF4A544E),
    surfaceContainer = Color(0xFFF0F4F0),
    surfaceContainerHigh = Color(0xFFE9EEE9),
    surfaceContainerLow = Color(0xFFF3F6F3),
    outline = Color(0xFF9AA59D),
    outlineVariant = Color(0xFFD0D8D2),
)

@Composable
fun ArchiveXTheme(dark: Boolean, accent: Int, content: @Composable () -> Unit) {
    val a = Accent.values()[accent.coerceIn(0, Accent.values().lastIndex)]
    val scheme = if (dark) {
        Dark.copy(primary = a.dark, primaryContainer = a.darkContainer, secondary = a.dark)
    } else {
        Light.copy(primary = a.light, primaryContainer = a.lightContainer, secondary = a.light)
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
