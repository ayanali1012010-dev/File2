# ArchiveX

A Kotlin / Jetpack Compose file manager and archive utility for Android (min SDK 26, target SDK 34).
Dark green theme, breadcrumb navigation, multi-select, long-press action sheet, archive browsing and
a progress dialog with speed + cancel.

## Get an APK without installing anything
1. Create an empty repository on GitHub (github.com > New repository). Do not add a README.
2. Push this folder:
   ```
   git init && git add . && git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```
3. Open the repo's **Actions** tab > "Build Android APK". When it finishes (about 5-8 minutes),
   download `app-debug.apk` from **Artifacts**, or from **Releases** on the repo's right sidebar.
   Run it manually any time: Actions > Build Android APK > Run workflow.

Optional release signing: add repo secrets `KEYSTORE_BASE64` (base64 of your .jks), `KEYSTORE_PASSWORD`,
`KEY_ALIAS`, `KEY_PASSWORD`. Without them the release APK is signed with the debug key.

## Formats
| | Browse | Extract | Create |
|---|---|---|---|
| ZIP | yes | yes (AES/ZipCrypto passwords) | yes (AES-256 password optional) |
| 7Z | yes | yes (passwords) | yes (no password) |
| RAR | yes | yes, RAR 2.x-4.x only | no |
| TAR, TAR.GZ/TGZ, TAR.BZ2, TAR.XZ | yes | yes | TAR, TAR.GZ |
| GZ, BZ2, XZ (single file) | yes | yes | no |
| ISO, CAB | no | no | no |
